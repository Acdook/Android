package com.ailsadora.bmi;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

/**
 * Created by ailsadora on 16/12/16.
 */

public class ResultActivity extends AppCompatActivity {

    private TextView tvShowResult;
    private Button btnBack;
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_result);

        findView();
        showResult();
    }

    private void findView()
    {
        tvShowResult=(TextView)findViewById(R.id.showResult);
        btnBack=(Button)findViewById(R.id.btnBack);

        btnBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onBackClick(v);
            }
        });
    }

    private void showResult()
    {
        Bundle bundle=this.getIntent().getExtras();
        Bmi bmi=(Bmi)bundle.getSerializable("bmi");
        double bmiValue=bmi.getBmiValue();
        StringBuilder sb=new StringBuilder();
        sb.append("BMI:"+bmiValue);
        if (bmiValue>24)
        {
            sb.append("\n太重啦,肥肥!");
        }
        else if (bmiValue>=18.5)
        {
            sb.append("\n标准身材,棒棒!");
//            sb.append("\n小混蛋最可爱啦~~~");
        }
        else
        {
            sb.append("\n太轻!");
        }
        tvShowResult.setText(sb);
    }

    public void onBackClick(View view)
    {
        this.finish();
    }
}
