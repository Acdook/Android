package com.ailsadora.bmi;

import java.io.Serializable;

/**
 * Created by ailsadora on 16/12/16.
 */

public class Bmi implements Serializable {
    private static final long serialVersionUID=605414019;
    private double mHeight,mWeight;

//    public  Bmi()
//    {
//        super();
//    }

    public Bmi(double mHeight,double mWeight)
    {
        super();
        this.mHeight=mHeight;
        this.mWeight=mWeight;
    }

    public double getBmiValue()
    {
        double bmiValue=mWeight/((mHeight/100)*(mHeight/100));
        return bmiValue;
    }

//    public void setmHeight(double mHeight)
//    {
//        this.mHeight=mHeight;
//    }
//
//    public double getmHeight()
//    {
//        return mHeight;
//    }
//
//    public void setmWeight(double mWeight)
//    {
//        this.mHeight=mWeight;
//    }
//    public double getmWeight()
//    {
//        return mWeight;
//    }
}
