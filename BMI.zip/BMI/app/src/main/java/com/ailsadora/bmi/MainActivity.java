package com.ailsadora.bmi;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class MainActivity extends AppCompatActivity {

    private Button checkButton;
    private EditText etHeight,etWeight;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        findView();
    }

    private void findView()
    {
        etHeight=(EditText)findViewById(R.id.editHeight);
        etWeight=(EditText)findViewById(R.id.editWeight);
        checkButton=(Button)findViewById(R.id.btnCheck);

        checkButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onSubmitCheck(v);
            }
        });
    }

    public void onSubmitCheck(View view)
    {
        double mHeight=Double.parseDouble(etHeight.getText().toString());
        double mWeight=Double.parseDouble(etWeight.getText().toString());

        Bmi bmi=new Bmi(mHeight,mWeight);
        Bundle bundle=new Bundle();

//        存对象需要实例化
        bundle.putSerializable("bmi",bmi);

//        存数据类型的东西则不用实例化,如下,可以直接存。数据类型是在上面定义后直接赋值,因为它是基本数据类型(Double)
//        bundle.putDouble("height",mHeight);

//        Activity必须在AndroidManifest.xml里声明
//        Intent 就是一个可以传输东西的媒介,譬如想广播东西,想跳转页面,具体看官网:https://developer.android.com/reference/android/content/Intent.html

        Intent intent=new Intent(this,ResultActivity.class);
        intent.putExtras(bundle);
        startActivity(intent);
    }
}
